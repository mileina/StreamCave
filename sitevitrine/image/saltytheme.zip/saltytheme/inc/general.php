<?php
function saltytheme_setup() {

	load_theme_textdomain( 'saltytheme', get_template_directory() . '/languages' );
	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	register_nav_menus(
		array(
			'menu-1' => esc_html__( 'Primary', 'saltytheme' ),
			'menu-footer' => esc_html__('Menu Footer', 'saltytheme'),
		)
	);
}

add_action( 'after_setup_theme', 'saltytheme_setup' );


function saltytheme_content_width() {
	$GLOBALS['content_width'] = apply_filters( 'saltytheme_content_width', 640 );
}
add_action( 'after_setup_theme', 'saltytheme_content_width', 0 );


function saltytheme_scripts() {
	wp_enqueue_style( 'saltytheme-style', get_stylesheet_uri(), array(), '1.0.0' );
	
	//JS
	wp_enqueue_script( 'fontawesome', 'https://kit.fontawesome.com/501d33add6.js', array(), '1.0.0' );
	wp_enqueue_script( 'partner_js', get_template_directory_uri() . '/assets/js/partner.js', array(), '1.0.0' );
	wp_enqueue_script( 'loader_js', get_template_directory_uri() . '/assets/js/loader.js', array(), '1.0.0' );

	if (is_page_template('templates/homepage.php')){
		wp_enqueue_script( 'Jquery', 'https://code.jquery.com/jquery-3.6.0.min.js', array(), '1.0.0' );
		wp_enqueue_script('EventSlidejs', get_template_directory_uri() . '/assets/js/event_slide.js', array(), '1.0.0', true);
		wp_enqueue_script( 'sections_js', get_template_directory_uri() . '/assets/js/sections.js', array(), '1.0.0' );
		wp_enqueue_script( 'twitch_js', "https://embed.twitch.tv/embed/v1.js", array(), '1.0.0' );
		wp_enqueue_script( 'twitch_api', get_template_directory_uri() . '/assets/js/twitch_api.js', array(), '1.0.0' );
		wp_enqueue_script( 'notif_js', get_template_directory_uri() . '/assets/js/notif.js', array(), '1.0.0' );
	}
	
}
add_action( 'wp_enqueue_scripts', 'saltytheme_scripts' );