<?php

class QueryRequests
{
    public function singleEventResquest(){
        $arg =
        [
            'post_type'  =>'evenement',
            'post_status'=>'publish',
            'posts_per_page' => 1,
            'orderby' => 'date',
            'order' => 'DESC',
        ];
    
        $the_query = new WP_Query($arg);
        return $the_query;
    }

    public function manyEventRequest(){
        $arg =
    [
        'post_type'  =>'evenement',
        'post_status'=>'publish',
        'posts_per_page' => 20,
        'orderby' => 'date',
        'order' => 'DESC',
    ];

        $the_query = new WP_Query($arg);
        return $the_query;
    }

    public function partnerResquest(){
        $arg =
        [
            'post_type'  =>'partenaires',
            'post_status'=>'publish',
            'posts_per_page' => 20,
            'orderby' => 'date',
            'order' => 'DESC',
        ];
    
        $the_query = new WP_Query($arg);
        return $the_query;
    }

    public function youtubeApiRequest($channelID, $maxResults)
    {
        $yt_api_key = 'AIzaSyCpU89hcxj7ZSHSsrn_RQzzefC6uErAxlk';

        $apiData = file_get_contents('https://www.googleapis.com/youtube/v3/search?order=date&part=snippet&channelId='.$channelID.'&maxResults='.$maxResults.'&key='.$yt_api_key.'');
            if($apiData){ 
                $videoList = json_decode($apiData); 
                return $videoList;
            }
    }
}
