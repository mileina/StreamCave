<?php

function debug($tableau)
{
    echo '<pre style="height:400px;overflow-y: scroll;font-size: .7rem;padding: .6rem;font-family: Consolas, Monospace;background-color: #000;color:#fff;">';
    print_r($tableau);
    echo '</pre>';
}

function path($slug)
{
    return esc_url(home_url($slug));
}

function getInfo(array $array,$champBdd){
    if (!empty($array[$champBdd][0])) {
        $info = $array[$champBdd][0];
        return $info;
    }
}

function metaFieldImg($meta, $string, $img_size){
    if (!empty($meta[$string][0])){
        return wp_get_attachment_image_url($meta[$string][0], $img_size);
    } else{
        return 'Image not found';
    }
}

function metaFieldOriginalImg($meta, $string){
    if (!empty($meta[$string][0])){
        return wp_get_attachment_image_url($meta[$string][0]);
    } else{
        return 'Image not found';
    }
}

function asset() {
    return  get_template_directory_uri().'/assets/img/';
}
