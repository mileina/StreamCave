<?php

function wpse_setup_theme() {
    add_theme_support( 'post-thumbnails' );
    add_image_size('eventImg',360,200);
    add_image_size('bannerImg',1300,160, true);
    add_image_size('logoImg',128,122, true);
    add_image_size('logoMediumImg',250,250);
    add_image_size('bgImg',1750,1080);
    add_image_size('thumbnailEvent',700,520);
 }
  
 add_action( 'after_setup_theme', 'wpse_setup_theme' );


function remove_default_img_sizes($sizes)
{
    // ['thumbnail','medium', 'medium_large', 'large', '1536x1536', '2048x2048'];
    unset($sizes['medium']);
    unset($sizes['large']);
    unset($sizes['medium_large']);
    return $sizes;
}

add_filter('intermediate_image_sizes_advanced' ,'remove_default_img_sizes', 10, 1);