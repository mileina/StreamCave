<?php

require_once(__DIR__ . '/../vendor/autoload.php');


/**
 * Fetch tweets from a user's timeline. For full details of the endpoint, go to:
 * https://developer.twitter.com/en/docs/twitter-api/v1/tweets/timelines/api-reference/get-statuses-user_timeline
 * @param int $numTweets - the number of tweets to fetch. Can't be larger than 200
 * @param string $twitterUsername - the username of the twitter account you wish to get the latest tweets of.
 * @param string $authToken - your bearer auth token. If you don't know it then use the getBearerToken() method with
 * your key and secret.
 * @return array - a collection of tweet response objects (in array format)
 */
function getTweets(int $numTweets, string $twitterUsername, string $authToken) : array
{
    $parameters = array(
        'screen_name' => $twitterUsername,
        'count' => $numTweets,
        'include_rts'=> false,
    );

    $headers = array(
        'Authorization' => 'Bearer ' . $authToken
    );

    $request = new Programster\GuzzleWrapper\Request(
        Programster\GuzzleWrapper\Method::createGet(),
        $url = 'https://api.twitter.com/1.1/statuses/user_timeline.json',
        $parameters,
        $headers,
        $useFormParams=false
    );

    $response = $request->send();
    $responseBody = $response->getBody();
    $responseBodyArray = json_decode($responseBody, true);
    return $responseBodyArray;
}