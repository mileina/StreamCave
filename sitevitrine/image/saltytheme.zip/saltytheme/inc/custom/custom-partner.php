<?php
/**
 * Register a custom post type called "partenaires".
 *
 * @see get_post_type_labels() for label keys.
 */
function wpdocs_codex_partenaires_init() {
    $labels = array(
        'name'                  => _x( 'Partenaires', 'Post type general name', 'textdomain' ),
        'singular_name'         => _x( 'Partenaires', 'Post type singular name', 'textdomain' ),
        'menu_name'             => _x( 'Partenaires', 'Admin Menu text', 'textdomain' ),
        'name_admin_bar'        => _x( 'Partenaires', 'Ajouter on Toolbar', 'textdomain' ),
        'add_new'               => __( 'Ajouter', 'textdomain' ),
        'add_new_item'          => __( 'Ajouter Partenaires', 'textdomain' ),
        'new_item'              => __( 'Nouvel Partenaires', 'textdomain' ),
        'edit_item'             => __( 'Modifier Partenaires', 'textdomain' ),
        'view_item'             => __( 'Voir Partenaires', 'textdomain' ),
        'all_items'             => __( 'Tous les Partenaires', 'textdomain' ),
        'search_items'          => __( 'Recherche Partenaires', 'textdomain' ),
        'parent_item_colon'     => __( 'Parent Partenaires:', 'textdomain' ),
        'not_found'             => __( 'Aucun Partenaires.', 'textdomain' ),
        'not_found_in_trash'    => __( 'Aucun Partenaires in Trash.', 'textdomain' ),
        'featured_image'        => _x( 'Image Partenaires', 'Overrides the “Featured Image” phrase for this post type. Added in 4.3', 'textdomain' ),
        'set_featured_image'    => _x( 'Modifier image Partenaires', 'Overrides the “Set featured image” phrase for this post type. Added in 4.3', 'textdomain' ),
        'remove_featured_image' => _x( 'Supprimer image Partenaires', 'Overrides the “Remove featured image” phrase for this post type. Added in 4.3', 'textdomain' ),
        'use_featured_image'    => _x( 'Utiliser comme image de fond', 'Overrides the “Use as featured image” phrase for this post type. Added in 4.3', 'textdomain' ),
        'archives'              => _x( 'Partenaires archives', 'The post type archive label used in nav menus. Default “Post Archives”. Added in 4.4', 'textdomain' ),
        'insert_into_item'      => _x( 'Inserer dans Partenaires', 'Overrides the “Insert into post”/”Insert into page” phrase (used when inserting media into a post). Added in 4.4', 'textdomain' ),
        'uploaded_to_this_item' => _x( 'Modifier dans cet Partenaires', 'Overrides the “Uploaded to this post”/”Uploaded to this page” phrase (used when viewing media attached to a post). Added in 4.4', 'textdomain' ),
        'filter_items_list'     => _x( 'Filtrer la liste Partenaires', 'Screen reader text for the filter links heading on the post type listing screen. Default “Filter posts list”/”Filter pages list”. Added in 4.4', 'textdomain' ),
        'items_list_navigation' => _x( 'Liste de navigation Partenaires', 'Screen reader text for the pagination heading on the post type listing screen. Default “Posts list navigation”/”Pages list navigation”. Added in 4.4', 'textdomain' ),
        'items_list'            => _x( 'Liste Partenaires', 'Screen reader text for the items list heading on the post type listing screen. Default “Posts list”/”Pages list”. Added in 4.4', 'textdomain' ),
    );

    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => 'partenaires' ), // modifie le terme de l'url
        'capability_type'    => 'post', // soit de type "page" post => article mieux pour les books
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => null,
        'menu-icon'          => 'dashicons-book',
        'supports'           => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'comments' ),
    );

    register_post_type( 'partenaires', $args );
}

add_action( 'init', 'wpdocs_codex_partenaires_init' );