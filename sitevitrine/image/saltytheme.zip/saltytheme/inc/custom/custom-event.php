<?php
/**
 * Register a custom post type called "evenement".
 *
 * @see get_post_type_labels() for label keys.
 */
function wpdocs_codex_evenement_init() {
    $labels = array(
        'name'                  => _x( 'Evenement', 'Post type general name', 'textdomain' ),
        'singular_name'         => _x( 'Evenement', 'Post type singular name', 'textdomain' ),
        'menu_name'             => _x( 'Evenements', 'Admin Menu text', 'textdomain' ),
        'name_admin_bar'        => _x( 'Evenement', 'Ajouter on Toolbar', 'textdomain' ),
        'add_new'               => __( 'Ajouter', 'textdomain' ),
        'add_new_item'          => __( 'Ajouter Evenement', 'textdomain' ),
        'new_item'              => __( 'Nouvel Evenement', 'textdomain' ),
        'edit_item'             => __( 'Modifier Evenement', 'textdomain' ),
        'view_item'             => __( 'Voir Evenement', 'textdomain' ),
        'all_items'             => __( 'Tous les Evenements', 'textdomain' ),
        'search_items'          => __( 'Recherche Evenements', 'textdomain' ),
        'parent_item_colon'     => __( 'Parent Evenements:', 'textdomain' ),
        'not_found'             => __( 'Aucun Evenement.', 'textdomain' ),
        'not_found_in_trash'    => __( 'Aucun Evenement in Trash.', 'textdomain' ),
        'featured_image'        => _x( 'Image Evenement', 'Overrides the “Featured Image” phrase for this post type. Added in 4.3', 'textdomain' ),
        'set_featured_image'    => _x( 'Modifier image Evenement', 'Overrides the “Set featured image” phrase for this post type. Added in 4.3', 'textdomain' ),
        'remove_featured_image' => _x( 'Supprimer image Evenement', 'Overrides the “Remove featured image” phrase for this post type. Added in 4.3', 'textdomain' ),
        'use_featured_image'    => _x( 'Utiliser comme image de fond', 'Overrides the “Use as featured image” phrase for this post type. Added in 4.3', 'textdomain' ),
        'archives'              => _x( 'Evenement archives', 'The post type archive label used in nav menus. Default “Post Archives”. Added in 4.4', 'textdomain' ),
        'insert_into_item'      => _x( 'Inserer dans Evenement', 'Overrides the “Insert into post”/”Insert into page” phrase (used when inserting media into a post). Added in 4.4', 'textdomain' ),
        'uploaded_to_this_item' => _x( 'Modifier dans cet Evenement', 'Overrides the “Uploaded to this post”/”Uploaded to this page” phrase (used when viewing media attached to a post). Added in 4.4', 'textdomain' ),
        'filter_items_list'     => _x( 'Filtrer la liste Evenement', 'Screen reader text for the filter links heading on the post type listing screen. Default “Filter posts list”/”Filter pages list”. Added in 4.4', 'textdomain' ),
        'items_list_navigation' => _x( 'Liste de navigation Evenement', 'Screen reader text for the pagination heading on the post type listing screen. Default “Posts list navigation”/”Pages list navigation”. Added in 4.4', 'textdomain' ),
        'items_list'            => _x( 'Liste Evenement', 'Screen reader text for the items list heading on the post type listing screen. Default “Posts list”/”Pages list”. Added in 4.4', 'textdomain' ),
    );

    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => 'evenement' ), // modifie le terme de l'url
        'capability_type'    => 'post', // soit de type "page" post => article mieux pour les books
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => null,
        'menu-icon'          => 'dashicons-book',
        'supports'           => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'comments' ),
    );

    register_post_type( 'evenement', $args );
}

add_action( 'init', 'wpdocs_codex_evenement_init' );