window.addEventListener("load", function() {
const allPartners = document.querySelectorAll('.partner');
let current = 0;

allPartners[0].style.display="block";

function fadeInFadeOut(){
    for (let i = 0; i < allPartners.length; i++) {
        allPartners[i].style.display="none";
        allPartners[i].classList="fadeout";
    }
    current = (current != allPartners.length - 1) ? current + 1 : 0;
    allPartners[current].style.display="block";
    allPartners[current].classList="fadein";
}

setInterval(fadeInFadeOut, 3000);
    
})


