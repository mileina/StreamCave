window.addEventListener("load", function(event) {
    new Twitch.Embed("twitch-embed", {
        channel: "sixquatre",
    });
})
