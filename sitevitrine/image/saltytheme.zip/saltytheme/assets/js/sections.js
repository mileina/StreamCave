window.addEventListener("load", function(event) {
    let onglets = document.getElementById('onglets');
    let contenus = document.getElementById('contenus');

    let liOnglet = onglets.querySelectorAll('.onglets_entity');
    let liContenu = contenus.querySelectorAll('.content_entity');

    liOnglet[0].className = "actif btn_hover_animation";
    liContenu[0].className = "actif";

    for (let i = 0; i < liOnglet.length; i++){
        liOnglet[i].num = i;

        liOnglet[i].addEventListener("click", function(){
            for (var j = 0; j < liOnglet.length; j++){
                liOnglet[j].className="btn_hover_animation";
                liContenu[j].className="";
            }

            liOnglet[this.num].className="actif";
            liContenu[this.num].className="actif";
        });
    }
})


