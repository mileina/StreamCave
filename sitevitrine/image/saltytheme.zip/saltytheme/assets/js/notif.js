//Stocker cookie date ouverture session ⇒ si existe pas 
//⇒ affiche notif ⇒ si existe et < à la date de mise en ligne de la 
//derniere vidéo ⇒ affiche notif 
//⇒ quand clique sur l’onglet, mise à jour du cookie sessionDate
window.addEventListener("load", function() {
    const onglet = document.querySelector("#video_onglet");
    const notif = document.querySelector(".notif_on_js");
    //On récupère les localStorage
    let latestSessionStorage = localStorage.getItem('sessionDate');
    let latestVideoStorage = localStorage.getItem('latestVideo');
    //On recupère la date du jour => convertie en ISO comme la date des vidéos dans le json
    let today = new Date().toISOString();

    //function pour maj de SessionDate
    function MajNotifLocalStorage(key, value){
        notif.classList.replace("notif_on_js", "notif_off_js");
        localStorage.setItem(key, value);
    }

    //On va lire le cache des vidéos youtube
    fetch("wp-content/themes/saltytheme/templates/tmp/jsonFile.json")
    .then(response => {
    return response.json();
    })
    .then(jsondata => {
        //On recupère la date de la dernière vidéo youtube dans le json
        let latestYtVideo = jsondata.items[0].snippet.publishedAt;
        localStorage.setItem('latestVideo', latestYtVideo);  
    });
    
    if(latestSessionStorage){
        //On regarde si la date de latestVideoStorage > latestSessionStorage
        //=> si c'est le cas affiche la notif
        if(latestVideoStorage > latestSessionStorage){
            onglet.addEventListener("click", function(){
                MajNotifLocalStorage('sessionDate', today);
            })
        }else{
            notif.classList.replace("notif_on_js", "notif_off_js");
        }  
    }else{
        //mise à jour
        onglet.addEventListener("click", function(){
            MajNotifLocalStorage('sessionDate', today);
        })
    }
})
