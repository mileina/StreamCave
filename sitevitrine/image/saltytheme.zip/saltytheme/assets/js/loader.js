window.addEventListener("load", function(e) {
    const loader = document.getElementById("loader");
    const websiteContainer = document.getElementById("global_container");
    loader.className="loaderTransition";
    loader.style.display="none";
    websiteContainer.style.display="flex";
})