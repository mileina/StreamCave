<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package saltyTheme
 */


$requestObj = new QueryRequests();

$metas = get_post_meta(get_the_ID());
$the_single_query_event = $requestObj->singleEventResquest();
$partnerResquest = $requestObj->partnerResquest();
?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<title>Salty Academy - Site officiel de Sixquatre</title>
	<meta name="description" content="Venez découvrir le site officiel de la Salty Academy ! ">

	<!-- Open Graph meta pour Facebook -->
	<meta property="og:title" content="Salty Academy - Site officiel de Sixquatre" />
	<meta property="og:url" content="https://www.salty-academy.com/" />
	<meta property="og:image" content="https://pbs.twimg.com/profile_images/1478107889495687171/Vsb7NWo7_400x400.jpg" />
	<meta property="og:description" content="Venez découvrir le site officiel de la Salty Academy !" />
	<meta property="og:site_name" content="Salty Academy" />
	<meta property="og:type" content="website" />

	<!-- Card meta pour Twitter -->
	<meta name="twitter:site" content="@Sixquatre">
	<meta name="twitter:title" content="Salty Academy" />
	<meta name="twitter:description" content="Venez découvrir le site officiel de la Salty Academy !" />
	<!-- Twitter summary card avec image large de 280x150px -->
	<meta name="twitter:image:src" content="https://pbs.twimg.com/profile_images/1478107889495687171/Vsb7NWo7_400x400.jpg" />

	<?php wp_head(); ?>
</head>


<body style="background-image: url('<?= metaFieldImg($metas, 'website_bg_img', 'bgImg') ?>'); background-size: cover; background-repeat: no-repeat;" <?php body_class(); ?>>
<?php wp_body_open(); ?>

    <div id="loader">
		<div class="loader_buttons">
			<div class="one"></div>
			<div class="two"></div>
			<div class="three"></div>
		</div>
        
		<?php if(!empty($metas)){ 
			if(is_page_template('templates/homepage.php')){ ?>
				<img src="<?= metaFieldImg($metas, 'gif_loader', 'eventImg') ?>" alt="logo de chargement">
			<?php }elseif(is_page_template('templates/mentions_legales.php')){ ?>
				<img src="<?= metaFieldImg($metas, 'mention_loader', 'eventImg') ?>" alt="logo de chargement">
			<?php } ?>
		<?php } ?>
		
    </div>

	<header id="masthead" class="site-header">
		<div id="top_bar">
			<div class="top_bar_bloc">
				<p>Annonce</p>
			</div>
			
			<?php
			if(!empty($the_single_query_event)){
                $the_single_query_event->have_posts();
                $the_single_query_event->the_post(); ?>
					<div class="event_message">
						<p><?= get_the_title() ?> <i class="fa-solid fa-arrow-right-long"></i> <?= get_the_excerpt() ?></p>
					</div>
			<?php } wp_reset_postdata(); ?>

			<div class="top_bar_bloc">
				<?php
				if(!empty($partnerResquest)){
					$partnerResquest->have_posts();
					while ( $partnerResquest->have_posts()) {
						$partnerResquest->the_post();
						$partner_metas = get_post_meta(get_the_ID()); ?>
						<img class="partner" src="<?= metaFieldImg($partner_metas, 'partner_thumbnail', 'eventImg') ?>" alt="<?= get_the_title(); ?>">
				<?php }} wp_reset_postdata(); ?>
			</div>
		</div>
		<!-- <img src="<?= metaFieldImg($metas, 'banner_img', 'bannerImg') ?>" alt="Bannière"> -->
    </header>
