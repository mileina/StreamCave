<?php
/*Template Name: HomePage*/

//Init Requests
$requestObj = new QueryRequests();

$metas = get_post_meta(get_the_ID());
$the_query = $requestObj->manyEventRequest();

//Init Cache
define('ROOT', dirname(__FILE__));
$cache = new Cache(ROOT . '/tmp', 60);

$channelID = 'UCkz0OAIQgpREGRDyHLaiI5A';
$maxResults = 4;

if (!$listYtApi = $cache->read('jsonFile.json')) {
    $listYtApi = $requestObj->youtubeApiRequest($channelID, $maxResults);
    $cache->write('jsonFile.json', $listYtApi);
    $jsonArray = $listYtApi;
} else {
    $jsonArray = $cache->read('jsonFile.json');
}

get_header();
?>
<div id="global_container" class="wrap" style="display: none;">

    <div class="primary_bloc_section">
        <div class="nav_bloc">
            <nav id="primary_nav">
                <div class="logo">
                    <a href="<?php echo path('/'); ?>">
                        <img src="<?= metaFieldImg($metas, 'logo_img', 'logoImg') ?>" alt="logo">
                    </a>
                </div>

                <div class="social_container">
                    <div class="social_items">
                        <ul>
                            <li><a target="_blank" class="tw" href="https://twitter.com/LaSaltyAcademy"><i class="fa-brands fa-twitter"></i></a></li>
                            <li><a target="_blank" class="discord" href="https://discord.gg/saltyacademy"><i class="fa-brands fa-discord"></i></a></li>
                            <li><a target="_blank" class="yt" href="https://www.youtube.com/channel/UCTHDkEmB6RZ6dExw0flCd7g/videos"><i class="fa-brands fa-youtube"></i></a></li>
                            <li><a target="_blank" class="tikTok" href="https://www.tiktok.com/@saltyacademy?lang=fr"><i class="fa-brands fa-tiktok"></i></a></li>
                            <li><a target="_blank" class="insta" href="https://www.instagram.com/salty_academy/"><i class="fa-brands fa-instagram"></i></a></li>
                        </ul>
                    </div>

                    <div class="app_link">
                        <ul id="onglets">
                            <li class="btn_hover_animation onglets_entity">
                                <div class="li_icon">
                                    <i class="fa-brands fa-twitch"></i>
                                </div>
                                <div class="li_text">
                                    <p>stream</p>
                                </div>
                            </li>
                            <li id="video_onglet" class="btn_hover_animation onglets_entity">
                                <div class="li_icon">
                                    <i class="fa-brands fa-youtube"></i>
                                </div>
                                <div class="li_text">
                                    <i class="notif_on_js fa-solid fa-circle-exclamation"></i>
                                    <p>Vidéos</p>
                                </div>
                            </li>
                            <li class="btn_hover_animation onglets_entity">
                                <div class="li_icon">
                                    <i class="fa-brands fa-instagram"></i>
                                </div>
                                <div class="li_text">
                                    <p>Photos</p>
                                </div>
                            </li>
                            <li class="btn_hover_animation onglets_entity">
                                <div class="li_icon">
                                    <i class="fa-solid fa-book"></i>
                                </div>
                                <div class="li_text">
                                    <p>Bio</p>
                                </div>
                            </li>
                            <a class="btn_hover_animation" target="_blank" href="https://maaku-shop.com">
                                <div class="li_icon">
                                    <i class="fa-solid fa-bag-shopping"></i>
                                </div>
                                <div class="li_text">
                                    <p>goodies</p>
                                </div>
                            </a>
                            <a class="btn_hover_animation" target="_blank" href="http://boutique.salty-academy.com">
                                <div class="li_icon">
                                    <i class="fa-solid fa-shop"></i>
                                </div>
                                <div class="li_text">
                                    <p>Boutique</p>
                                </div>
                            </a>
                            <a class="btn_hover_animation" target="_blank" href="https://www.amazon.fr/shop/sixquatre/list/9S41066A4SAF">
                                <div class="li_icon">
                                    <i class="fa-solid fa-computer-mouse"></i>
                                </div>
                                <div class="li_text">
                                    <p>Mon stuff</p>
                                </div>
                            </a>
                        </ul>
                    </div>

                </div>
            </nav>

            <div id="section_container">
                <ul id="contenus">
                    <li class="content_entity">
                        <div id="twitch-embed"></div>
                    </li>

                    <li class="content_entity">
                        <div>
                            <iframe class="yt_video" src="https://www.youtube.com/embed/videoseries?list=UUkz0OAIQgpREGRDyHLaiI5A" title="YouTube video player" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                        </div>
                    </li>

                    <li id="insta_content" class="content_entity">
                        <!-- Shortcode SmashBallon -->
                        <?= do_shortcode("[instagram-feed feed=3]"); ?>
                    </li>

                    <li class="content_entity">
                        <iframe id="wiki_article" src="https://fr.wikipedia.org/wiki/Sixquatre"></iframe>
                    </li>

                </ul>
            </div>
        </div>

        <div class="yt_thumbnail_title">
            <h2>Dernières vidéos : </h2>
        </div>

        <div id="yt_thumbnail_section">
            <?php
            if (!empty($jsonArray)) {
                foreach ($jsonArray->items as $item) { ?>
                    <div class="thumbnail_box">
                        <div class="item">
                            <a target="_blank" href="https://www.youtube.com/watch?v=<?= $item->id->videoId ?>"><img src="<?= $item->snippet->thumbnails->medium->url ?>" alt="<?= $item->snippet->title ?>"></a>
                            <div class="overlay title-overlay">
                                <a target="_blank" href="https://www.youtube.com/watch?v=<?= $item->id->videoId ?>">
                                    <div class="text"><?= $item->snippet->title ?></div>
                                </a>
                            </div>
                        </div>
                    </div>
            <?php }
            } ?>
        </div>
    </div>

    <nav id="secondary_nav">
        <div class="news_container">
            <blockquote class="tiktok-embed" cite="https://www.tiktok.com/@saltyacademy" data-unique-id="saltyacademy" data-embed-type="creator">
                <section>
                    <a target="_blank" href="https://www.tiktok.com/@saltyacademy?refer=creator_embed"></a>
                </section>
            </blockquote>

            <div class="tw_content">
                <div class="tw_item">
                    <a class="twitter-timeline" data-height="370" data-theme="light" href="https://twitter.com/Sixquatre?ref_src=twsrc%5Etfw">Tweets by Sixquatre</a>
                    <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>
                </div>
            </div>
        </div>
    </nav>
</div>

<div id="discord_floating" class="floating">
    <a target="_blank" href="https://discord.gg/saltyacademy"><i class="fa-brands fa-discord"></i></a>
</div>

<script async src="https://www.tiktok.com/embed.js"></script>
<?php
get_footer();
