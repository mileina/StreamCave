<?php
require_once get_template_directory() . '/inc/general.php';
require_once get_template_directory() . '/inc/func.php';
require_once get_template_directory() . '/inc/classes/Request.php';
require_once get_template_directory() . '/inc/classes/Cache.php';
require_once get_template_directory() . '/inc/image.php';
require_once get_template_directory() . '/inc/extra/template-tags.php';
require_once get_template_directory() . '/inc/extra/template-functions.php';
require_once get_template_directory() . '/inc/custom/custom-event.php';
require_once get_template_directory() . '/inc/custom/custom-partner.php';