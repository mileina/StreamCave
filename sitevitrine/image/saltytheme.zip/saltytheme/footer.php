<?php
$metas = get_post_meta(get_the_ID());
?>
<footer id="colophon" class="site-footer">

	<div class="wrap">
		<div class="footer_logo">
			<h2>Salty Academy</h2>
			<p>By Sixquatre</p>

			<?php if (!empty($metas)) {
				if (is_page_template('templates/homepage.php')) { ?>
					<img src="<?= metaFieldImg($metas, 'logo_img', 'logoImg') ?>" alt="logo">
				<?php } elseif (is_page_template('templates/mentions_legales.php')) { ?>
					<img src="<?= metaFieldImg($metas, 'footer_logo_mention', 'logoImg') ?>" alt="logo">
				<?php } ?>
			<?php } ?>

		</div>

		<div class="footer_list">
			<h3>Réseaux sociaux</h3>
			<div class="separator_title"></div>
			<ul class="social_list">
				<div class="footer_social_column">
					<li><a target="_blank" href="https://www.twitch.tv/sixquatre?lang=fr"><i class="fa-brands fa-twitch"></i>Twitch</a></li>
					<li><a target="_blank" href="https://www.youtube.com/channel/UCTHDkEmB6RZ6dExw0flCd7g/videos"><i class="fa-brands fa-youtube"></i>Youtube</a></li>
					<li><a target="_blank" href="https://discord.gg/saltyacademy"><i class="fa-brands fa-discord"></i>Discord</a></li>
				</div>
				<div class="footer_social_column">
					<li><a target="_blank" href="https://www.instagram.com/salty_academy/"><i class="fa-brands fa-instagram"></i>Instagram</a></li>
					<li><a target="_blank" href="https://twitter.com/LaSaltyAcademy"><i class="fa-brands fa-twitter"></i>Twitter</a></li>
					<li><a target="_blank" href="https://www.tiktok.com/@saltyacademy?lang=fr"><i class="fa-brands fa-tiktok"></i>Tiktok</a></li>
				</div>

			</ul>
		</div>

		<div class="footer_list">
			<h3>Informations</h3>
			<div class="separator_title"></div>
			<ul>
				<li><a href="<?= path('mentions-legales'); ?>">Mentions Légales</a></li>
				<li><a href="mailto:saltyacademy.pro@gmail.com">Nous contacter</a></li>
			</ul>
		</div>
	</div>

	<div id="footer_copyright">
		<p>&copy; Salty Academy 2023</p>
	</div>
</footer><!-- #colophon -->
<?php wp_footer(); ?>

</body>

</html>